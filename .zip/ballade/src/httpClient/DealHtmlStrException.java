package httpClient;

public class DealHtmlStrException extends Exception {

	private String error;
	
	public DealHtmlStrException() {
		
	}
	
	public DealHtmlStrException(String error) {
		this.error = error;
	}
	
	public String toString() {
		return error;
	}
}
