package httpClient.post.param.object;

import java.util.Map;

public interface PagePostParams {

	public Map<String, String> getPostParams();
}
