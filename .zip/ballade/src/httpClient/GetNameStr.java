package httpClient;

import java.io.IOException;
import java.util.List;

import org.apache.http.cookie.Cookie;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class GetNameStr {

	@Autowired
	private TeachNetHttpClient client;

	private static final String NAME_URL = "http://202.202.1.176:8080/PUB/foot.aspx";
	
	public String getNameStr(List<Cookie> cookies) throws IOException {
		String html = client.saveTableHtmlStr(cookies, NAME_URL, null);
		return html.split("id=TheFootMemo")[1].split("]")[1].split("</div>")[0];
	}
}
