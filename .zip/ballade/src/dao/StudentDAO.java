package dao;

public interface StudentDAO {

	public void saveStudent(String username, String password);
}
