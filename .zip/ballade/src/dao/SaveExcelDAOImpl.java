package dao;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import teachnet.info.object.lesson.Lesson;
import teachnet.info.object.lesson.LessonDetailConverter;
import teachnet.info.object.InfoObject;

@Component
public class SaveExcelDAOImpl implements SaveExcelDAO {

	@Autowired
	private LessonDetailConverter lessonConverter;
	
	public void saveIntoExcel(List<InfoObject> lessons, OutputStream os, int year, int month, int date) {
		try {
			WritableWorkbook wwb = Workbook.createWorkbook(os);
			WritableSheet ws = wwb.createSheet("lesson", 0);
			ws.addCell(new Label(0, 0, "Subject"));		// name
			ws.addCell(new Label(1, 0, "Start Date"));	// 05/30/2020
			ws.addCell(new Label(2, 0, "Start Time"));	// 10:00 AM
			ws.addCell(new Label(3, 0, "End Date"));	// 05/30/2020
			ws.addCell(new Label(4, 0, "End Time"));	// 1:00 PM
			ws.addCell(new Label(5, 0, "All Day Event"));	//	False
			ws.addCell(new Label(6, 0, "Description"));	//	50 个多选题和 2 个问答题
			ws.addCell(new Label(7, 0, "Location"));	//	“北京大学，逸夫楼 209 室”
			ws.addCell(new Label(8, 0, "Private"));		// True
			Iterator<InfoObject> it1 = lessons.iterator();
			int i = 1;
			while(it1.hasNext()) {
				Iterator<Lesson> it2 = lessonConverter.convertDetail((Lesson) it1.next(), year, month, date).iterator();
				while(it2.hasNext()) {
					Lesson lesson = it2.next();
					ws.addCell(new Label(0, i, lesson.getShortName()));
					ws.addCell(new Label(1, i, lesson.getDate()));
					ws.addCell(new Label(2, i, lesson.getStartTime()));
					ws.addCell(new Label(3, i, lesson.getDate()));
					ws.addCell(new Label(4, i, lesson.getEndTime()));
					ws.addCell(new Label(5, i, "FALSE"));
					ws.addCell(new Label(6, i, "课程"));
					ws.addCell(new Label(7, i, lesson.getLocation()));
					ws.addCell(new Label(8, i, "TRUE"));
					i ++;
				}
			}
			wwb.write();
			wwb.close();
		} catch(IOException e) {
			e.printStackTrace();
		} catch (RowsExceededException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (WriteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if(os != null) {
				try {
					os.close();
				} catch(IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
