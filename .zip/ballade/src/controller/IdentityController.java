package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.cookie.Cookie;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import dao.StudentDAO;
import httpClient.GetNameStr;
import httpClient.TeachNetHttpClient;

@Controller
@RequestMapping("/identity")
public class IdentityController {
	
	@Autowired
	private TeachNetHttpClient client;
	
	@Autowired
	private StudentDAO studentDAO;
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private GetNameStr nameStr;
	
	@Autowired
    @Qualifier("org.springframework.security.authenticationManager")
    private AuthenticationManager authenticationManager;

	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String dealLoginPost(@RequestParam("username") String username, @RequestParam("password") String password, Model model) {
		try {
			List<Cookie> cookies = client.loginToTeachNet(username, password, TeachNetHttpClient.LOGIN_URL, client.getLoginPostParams(username, password), TeachNetHttpClient.CHARSET);
			request.getSession().setAttribute("cookies", cookies);
			String name = nameStr.getNameStr(cookies);
			if(name.equals("")) throw new NoNameException();
			request.getSession().setAttribute("name", name);
			studentDAO.saveStudent(username, "");
			securityCheckToLogin(username, "");
		} catch (IOException e) {
			model.addAttribute("loginError", "好像出了些问题");
			return "login";
		} catch(NoNameException e) {
			model.addAttribute("loginError", "账号密码错误");
			return "login";
		}
		return "redirect:/home";
	}
	
	private void securityCheckToLogin(String username, String password) {
		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(username, password);
	    token.setDetails(new WebAuthenticationDetails(request));
	    Authentication authenticatedUser = authenticationManager.authenticate(token);
	    SecurityContextHolder.getContext().setAuthentication(authenticatedUser);
	}
}
