package controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.cookie.Cookie;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import dao.SaveExcelDAO;
import dao.StudentDAO;
import httpClient.DealHtmlStrException;
import httpClient.GetNameStr;
import httpClient.SaveInfoDetail;
import httpClient.SaveLessonDetailImpl;
import httpClient.TeachNetHttpClient;
import httpClient.post.param.object.LessonPagePostParams;
import httpClient.post.param.object.ScorePagePostParams;
import teachnet.info.object.InfoObject;
import teachnet.info.object.lesson.Lesson;
import teachnet.info.object.lesson.LessonDetailConverter;
import teachnet.info.object.score.Score;

@Controller
public class HomeController {

	@Autowired
	private StudentDAO studentDAO;
	
	@Autowired
	private GetNameStr nameStr;
	
	@Autowired
	@Qualifier("saveLessonDetailImpl")
	private SaveInfoDetail lessonImpl;
	
	@Autowired
	@Qualifier("saveScoreDetailImpl")
	private SaveInfoDetail scoreImpl;
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private LessonDetailConverter lessonConverter;
	
	@Autowired
	private SaveExcelDAO excelDAO;
	
	private static final int YEAR = 2016;
	
	private static final int TERM = 0;
	
	private static final int BEGIN_MONTH = 9;
	
	private static final int BEGIN_DAY = 5;
	
	@RequestMapping("/")
	public String defaultIndex(Model model) {
		return showHomePage(model);
	}
	
	@RequestMapping("/home")
	public String showHomePage(Model model) {
		request.getSession().setAttribute("nowWeek", getNowWeek());
		return "home";
	}
	
	@RequestMapping("/login")
	public String showLoginPage() {
		return "login";
	}
	
	@RequestMapping(value="/home/calendar", method=RequestMethod.GET)
	public String calendarSelect(@RequestParam("week") String week, Model model) {
		model.addAttribute("studyYear", "" + YEAR + "-" + (YEAR + 1) + "学年");
		model.addAttribute("studyTerm", "第" + (TERM + 1) + "学期");
		model.addAttribute("nowDay", getNowDay());
		model.addAttribute("chiNums", getChiNums());
		model.addAttribute("selectedWeek", week);
		model.addAttribute("nowWeek", getNowWeek());
		List<String> dates = getDates(week);
		model.addAttribute("dates", dates);
		try {
			Map<String, Lesson> lessonMap = new HashMap<String, Lesson>();
			List<Cookie> cookies = (List<Cookie>) request.getSession().getAttribute("cookies");
			List<InfoObject> lessons = lessonImpl.getLessonsAndDetails(cookies, LessonPagePostParams.LESSON_PAGE_URL, new LessonPagePostParams(YEAR, TERM).getPostParams());
			Iterator<InfoObject> it = lessons.iterator();
			while(it.hasNext()) {
				Lesson lesson = (Lesson) it.next();
				List<Lesson> tempLessons = lessonConverter.convertDetail(lesson, YEAR, BEGIN_MONTH, BEGIN_DAY);
				Iterator<Lesson> it1 = tempLessons.iterator();
				while(it1.hasNext()) {
					Lesson lesson1 = it1.next();
					if(ifInWeek(lesson1, dates)) {
						lessonConverter.convertXYIndex(lesson1, dates);
						lessonConverter.judgeIfToBeDone(lesson1);
						lessonMap.put(lesson1.getYIndex() + lesson1.getXIndex(), lesson1);
					}
				}
			}
			model.addAttribute("lessons", lessonMap);
		} catch (IOException | DealHtmlStrException e) {
			return "home";
		}
		return "calendar/show";
	}
	
	@RequestMapping("/home/calendar/download")
	public String downloadCalendar(HttpServletResponse response) {
		response.setContentType("application/x-msdownload;");
        String username = getUsername();
        response.setHeader("Content-disposition", "attachment; filename="
                 + "lessonTable_" + username + ".csv");
		try {
			List<Cookie> cookies = (List<Cookie>) request.getSession().getAttribute("cookies");
			List<InfoObject> lessons = lessonImpl.getLessonsAndDetails(cookies, LessonPagePostParams.LESSON_PAGE_URL, new LessonPagePostParams(YEAR, TERM).getPostParams());
			excelDAO.saveIntoExcel(lessons, response.getOutputStream(), YEAR, BEGIN_MONTH, BEGIN_DAY);
		} catch (IOException | DealHtmlStrException e) {
			return "home";
		}
		return null;
	}
	
	@RequestMapping("/home/score/select")
	public String studyYearTermSelect(Model model) {
		model.addAttribute("years", getStudyYears(getUsername()));
		int nowYear = getNowYear();
		model.addAttribute("nowYear", String.valueOf(nowYear) + "-" + String.valueOf(++ nowYear));
		return "score/select";
	}
	
	@RequestMapping(value="/home/score", method=RequestMethod.GET)
	public String showScore(@RequestParam("year") int year, @RequestParam("term") int term, Model model) {
		model.addAttribute("years", getStudyYears(getUsername()));
		int nowYear = getNowYear();
		model.addAttribute("nowYear", String.valueOf(nowYear) + "-" + String.valueOf(++ nowYear));
		String termStr = "";
		if(term == 0) termStr = "第一学期";
		if(term == 1) termStr = "第二学期";
		model.addAttribute("selectedTerm", termStr);
		model.addAttribute("selectedYear", String.valueOf(year) + "-" + String.valueOf(year + 1));
		model.addAttribute("selectedShortTerm", term);
		List<Score> scores = new LinkedList<Score>();
		try {
			List<Cookie> cookies = (List<Cookie>) request.getSession().getAttribute("cookies");
			List<InfoObject> objects = scoreImpl.getLessonsAndDetails(cookies, ScorePagePostParams.SCORE_PAGE_URL, new ScorePagePostParams(false, year, term).getPostParams());
			Iterator<InfoObject> it = objects.iterator();
			while(it.hasNext()) {
				Score score = (Score) it.next();
				score.setShortName(score.convertName());
				scores.add(score);
			}
			model.addAttribute("scores", scores);
		} catch (IOException | DealHtmlStrException e) {
			return "redirect:/home";
		}
		return "score/show";
	}
	
	private List<String> getStudyYears(String username) {
		List<String> years = new LinkedList<String>();
		int beginYear = Integer.valueOf(username.substring(0, 4));
		int nowYear = getNowYear();
		while(beginYear <= nowYear) {
			String year = String.valueOf(beginYear) + "-" + String.valueOf(++ beginYear);
			years.add(year);
		}
		return years;
	}
	
	private int getNowYear() {
		String nowYearStr = new SimpleDateFormat("yyyy").format(new Date());
		int nowYear = Integer.valueOf(nowYearStr);
		String nowMonthStr = new SimpleDateFormat("MM").format(new Date());
		int nowMonth = Integer.valueOf(nowMonthStr);
		if(nowMonth < 9) {
			nowYear --;
		}
		return nowYear;
	}
	
	private String getUsername() {
		SecurityContext sc = SecurityContextHolder.getContext();
		Authentication auth = sc.getAuthentication();
		return auth.getName();
	}
	
	private String getNowDay() {
		Calendar calendar = Calendar.getInstance();
		return new SimpleDateFormat("MM/dd/yyyy").format(calendar.getTime());
	}
	
	private String getNowWeek() {
		Calendar beginCalendar = Calendar.getInstance();
		beginCalendar.set(YEAR, BEGIN_MONTH - 1, BEGIN_DAY);
		Calendar nowCalendar = Calendar.getInstance();
		Date beginDate = beginCalendar.getTime();
		Date nowDate = nowCalendar.getTime();
		int week = (int) ((nowDate.getTime() - beginDate.getTime()) / 1000 / 60 / 60 / 24 / 7);
		return String.valueOf(week + 1);
	}
	
	private boolean ifInWeek(Lesson lesson, List<String> dates) {
		Iterator<String> it = dates.iterator();
		while(it.hasNext()) {
			if(lesson.getDate().equals(it.next())) {
				return true;
			}
		}
		return false;
	}
	
	private List<String> getDates(String week) {
		List<String> dates = new LinkedList<String>();
		Calendar calendar = Calendar.getInstance();
		calendar.set(YEAR, BEGIN_MONTH - 1, BEGIN_DAY);
		calendar.add(3, Integer.valueOf(week) - 1);
		SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		for(int i = 0; i < 7; i ++) {
			if(i == 0) {
				calendar.add(5, 0);
			} else {
				calendar.add(5, 1);
			}
			dates.add(df.format(calendar.getTime()));
		}
		return dates;
	}
	
	private List<String> getChiNums() {
		List<String> weekDayNames = new LinkedList<String>();
		weekDayNames.add("一");
		weekDayNames.add("二");
		weekDayNames.add("三");
		weekDayNames.add("四");
		weekDayNames.add("五");
		weekDayNames.add("六");
		weekDayNames.add("日");
		return weekDayNames;
	}
}
