package controller;

public class NoNameException extends Exception {

}
