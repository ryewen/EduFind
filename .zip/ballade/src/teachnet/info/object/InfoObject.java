package teachnet.info.object;

public class InfoObject {

}
