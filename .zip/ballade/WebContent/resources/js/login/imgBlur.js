addOnLoad(makeBackgroundBlur("loginTable"));
addOnLoad(makeBackgroundBlur("homeDiv"));
addOnLoad(makeBackgroundBlur("showCalendar"));
addOnLoad(makeBackgroundBlur("scoreDiv"));
addOnLoad(errorAlert("loginError"));

function makeBackgroundBlur(id) {
	var element = document.getElementById(id);
	if(element == null) return;
	var img = document.createElement("img");
	img.setAttribute("src", "/ballade/resources/img/blank.png");
	img.style.opacity = "0.4";
	width = element.offsetWidth + 34;
	height = element.offsetHeight + 20;
	img.style.width = width + "px";
	img.style.height = height + "px";
	img.style.position = "absolute";
	img.style.top = "0px";
	img.style.left = "0px";
	var parent = element.parentNode;
	var div = document.createElement("div");
	div.appendChild(img);
	parent.insertBefore(div, element);
	element.parentNode = div;
	div.appendChild(element);
	div.style.position = "relative";
	element.style.position = "absolute";
	element.style.top = "10px";
	element.style.left = "17px";
}

function errorAlert(id) {
	var error = document.getElementById(id);
	if(error == null) return;
	error.style.width = "0px";
	error.style.height = "0px";
	error.style.padding = "0px";
	error.style.margin = "0px";
	error.style.borderWidth = "0px";
	error.style.display = "none";
	alert(error.firstChild.nodeValue);
}

function addOnLoad(func) {
	var oldOnLoad = window.onload;
	if((typeof oldOnLoad) != "function") {
		window.onload = func;
	} else {
		window.onload = function() {
			oldOnLoad();
			func();
		};
	}
}