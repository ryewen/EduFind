addOnLoad(putLeft());

function putLeft() {
	var left = document.getElementById("left");
	var right = document.getElementById("right");
	var leftWidth = left.offsetWidth;
	var rightWidth = right.offsetWidth;
	if(leftWidth > (document.body.clientWidth - rightWidth - 40)) {
		right.style.width = leftWidth + "px";
		right.style.height = "150px";
		var homeDiv = document.getElementById("homeDiv");
		homeDiv.style.width = leftWidth + "px";
		homeDiv.style.height = "150px";
		var table = document.getElementById("funcTable");
		table.style.marginTop = "0px";
		left.style.position = "absolute";
		left.style.top = right.offsetHeight + 40 + "px";
		document.getElementsByTagName("body")[0].style.backgroundSize = "135% 530%";
		document.getElementById("calendarForm").style.marginLeft = "0px";
	}
}

function addOnLoad(func) {
	var oldOnLoad = window.onload;
	if((typeof oldOnLoad) != "function") {
		window.onload = func;
	} else {
		window.onload = function() {
			oldOnLoad();
			func();
		};
	}
}